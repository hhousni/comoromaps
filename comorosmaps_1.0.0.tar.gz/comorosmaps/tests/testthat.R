library(testthat)
library(comorosmaps)

test_check("comorosmaps")
