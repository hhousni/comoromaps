utils::globalVariables(c("adminCode", "x","name","geometry"))
